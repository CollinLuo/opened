<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title>upload test</title>

    <!-- Bootstrap -->
    <link href="/upload/Public/bootstrap-3.3.4/css/bootstrap.min.css" rel="stylesheet">
	<!-- 引入uploadify样式 -->
    <link rel="stylesheet" type="text/css" href="/upload/Public/uploadify/uploadify.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
		.img_box{
			padding: 9px 14px;
			margin-bottom: 14px;
			background-color: #f7f7f9;
			border: 1px solid #e1e1e8;
			border-radius: 4px;
			min-height:200px;
		}		
		.img{			
			text-align:center;			
			display: inline-block;
			margin: auto;
			width: 100%;
			max-height: 200px;
			padding: 4px;			
			background-color: #fff;
			border: 1px solid #ddd;
			border-radius: 4px;		
		}
		.img_ctrl{
			text-align:center;			
			display: inline-block;
			/*position: absolute;*/
			width: 100%;
			/*height: auto;*/
			padding: 1px;			
			background-color: #fff;
			border: 1px solid #ddd;
			border-radius: 4px;
			margin-bottom: 4px;
		}
		.img_name{			
			display:none;			
			position:absolute;
			z-index: 2;
		}
		.modal-content{
			text-align: center;
		}
		#img_show{
			max-width: 100%;
		}
		#fileselect{
			display:none;
		}
    </style>
  </head>
  <body>
    <div class="container">
    	<h1>Upload Test</h1>
    	<div>    		
    		<input id="file_upload" name="file_upload" type="file" multiple="true">
    	</div>
    	<div class="row img_box" id="img_box">
    		   	
    	</div>

    	<hr>
    	<div class="form-group">
    		<label for=''>Html5 上传</label>
    		<button class="btn btn-primary" id="selsect">选择文件</button>
    		<input type="file" id="fileselect" class="form-control" name="fileselect[]" multiple="multiple"/> 
    	</div> 
    	

    	<div class="footer">
	    	<p class="pull-right"><strong>hbh112233abc@163.com</strong></p>
	    </div>   	
    </div>

    <div class="modal fade bs-example-modal-lg" id="modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-lg">
	    <div class="modal-content">
	    	<!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> -->
	    	<img id="img_show" src="" alt="">
	    </div>
	  </div>
	</div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="/upload/Public/js/jquery/jquery-1.11.3.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/upload/Public/bootstrap-3.3.4/js/bootstrap.min.js"></script>

	<!-- 引入uploadify的js代码 -->
	<script src="/upload/Public/uploadify/jquery.uploadify.min.js"></script>

	<!-- 复制专用插件 -->
	<script src="/upload/Public/js/jquery.zclip/jquery.zclip.js"></script>
	<!-- 引入livequery 用于新增对象方法绑定 -->
	<script src="/upload/Public/js/jquery.livequery.js"></script>
		
	<script>
		$(function() {
			$('#selsect').click(function(event) {
				$('#fileselect').click();
			});			
			//选择文件
			$('#fileselect').change(function(event) {			
		        event.preventDefault();
		        var n=event.target.files.length;		        
		        var file;		        
				for (var i = 0; i < n; i++) {
					file=event.target.files[i];
					html5up(file);
				};						        
			});	
			//上传操作
			function html5up(file){
				/* Act on the event */
				var form_data=new FormData();				
				form_data.append('timestamp',"<?php echo ($time); ?>");
				form_data.append('token','<?php echo md5("unique_salt".$time);?>');
				form_data.append("Filedata",file);							
				$.ajax({
					url: '<?php echo U("Index/upload",null,false);?>',
					type: 'POST',
					// dataType: 'default: Intelligent Guess (Other values: xml, json, script, or html)',
					processData: false,
					contentType: false,
					data: form_data,
				})
				.done(function(data) {
					// alert(data);					
		            if (!data.status) {
		            	alert(data.info);
		            	return false;
		            };		            
		            put_img(data.savepath,data.savename);//添加图片到img_box
					console.log("success");
				})
				.fail(function() {
					console.log("error");
				})
				.always(function() {
					console.log("complete");
				});
			
			}	
			//uploadify上传操作		
			$('#file_upload').uploadify({
				'formData'     : {
					'timestamp' : "<?php echo ($time); ?>",//当前时间戳由后台传过来的
					'token'     : '<?php echo md5("unique_salt".$time);?>'//用md5生成token
				},
				'swf'      : '/upload/Public/uploadify/uploadify.swf',//引用uploadify.swf
				'uploader' : '<?php echo U("Index/upload",null,false);?>',//后台上传文件处理方法
				'buttonText':'选择文件',
				'multi'           : true,//允许多文件上传
				'fileTypeExts' : '*.gif; *.jpg; *.png;',//限制文件格式
				'fileSizeLimit' : '5MB',//限制文件大小

				'onUploadSuccess' : function(file, data, response) {
		            var data = $.parseJSON(data);	
		            if (!data['status']) {
		            	alert(data['info']);
		            	return false;
		            };		            
		            put_img(data['savepath'],data['savename']);//添加图片到img_box
		        }
			});
			


			//添加图片到img_box
			function put_img(savepath,savename){
				var img_url="/upload"+savepath+savename;
				// alert(img_url);
				var new_img='<div class="col-md-3">';					
		            new_img+='<img src="'+img_url+'" alt="test" class="img">';
		            new_img+='<div class="img_ctrl">';
		            new_img+='<span class="glyphicon glyphicon-cloud-download btn" data-toggle="tooltip" data-placement="bottom" title="下载链接地址" aria-hidden="true"></span>';
		            new_img+='<span class="glyphicon glyphicon-trash btn" data-toggle="tooltip" data-placement="bottom" title="删除文件" aria-hidden="true"></span>';
		            new_img+='<span class="glyphicon glyphicon-tag btn" data-toggle="tooltip" data-placement="bottom" title="修改标题" aria-hidden="true"></span>';
		            new_img+='</div>';
		            new_img+='<div class="img_name">';
	    			new_img+='<form action="" class="form-inline">';
	    			new_img+='<input type="text" class="form-control input-sm savename" value="'+savename+'">';
	    			new_img+='<button class="btn btn-primary btn-sm save inline-block">保存</button>';
	    			new_img+='</form>';
	    			new_img+='</div>';
		            new_img+='</div>';

		            $('.img_box').append(new_img);
			}

			//复制图片地址
			$('.glyphicon-cloud-download').livequery(function(){
				$(this).zclip({
					path:'/upload/Public/js/jquery.zclip/ZeroClipboard.swf',
					copy:function(){
						return "http://"+"<?php echo ($_SERVER['HTTP_HOST']); ?>"+$(this).parents('div.col-md-3').find('.img').attr('src');						
					},
					afterCopy:function(){
						alert('成功复制图片地址');
					},
				});
			});
		

			//调出修改标题input
			$(document).on('click','.glyphicon-tag',function(event){
				var div=$(this).parents('div.col-md-3');
				var img_name=div.find('.img_name');
				img_name.fadeToggle();
			});

			//点击保存按钮
			$(document).on('click','.save',function(event){
				event.preventDefault();
				var img_name=$(this).parents('.img_name');
				var savename=img_name.find('.savename');
				var new_name=savename.val();
				// alert(new_name);
				var img=$(this).parents('div.col-md-3').find('.img');
				var img_url=img.attr('src');
				// alert(img_url);
				$.ajax({
					url: '<?php echo U("Index/changeName",null,false);?>',
					type: 'POST',
					// dataType: 'default: Intelligent Guess (Other values: xml, json, script, or html)',
					data: {url:img_url,name: new_name},
					success:function(data){
						// var data = $.parseJSON(data);
						// alert(data);return false;
						if (!data['status']) {
							alert(data['info']);
							return false;
						};
						savename.val(data['savename']);
						img.attr('src',"/upload"+data['savepath']);
						img_name.fadeOut('slow');
					}
				});

			});

			
			//图片删除
			$(document).on('click', '.glyphicon-trash', function(event) {
				event.preventDefault();
				/* Act on the event */
				var div=$(this).parents('div.col-md-3');
				var img_url=div.find('.img').attr('src');
				// alert(img_url);
				$.ajax({
					url: '<?php echo U("Index/del",null,false);?>',
					type: 'POST',
					// dataType: 'default: Intelligent Guess (Other values: xml, json, script, or html)',
					data: {url: img_url},
					success:function(data){
						if (!data['status']) {
							alert(data['info']);
							return false;
						}else{
							alert(data['info']);
							div.fadeOut(2000);
							div.remove();
						};
					}
				});			
				
			});

			//图片放大预览
			$(document).on('click', '.img', function(event) {
				event.preventDefault();
				/* Act on the event */
				var img_url=$(this).attr('src');
				$('#modal').modal('show');
				$('#img_show').attr('src',img_url);
			});
			
			//点击modal自动隐藏
			$('#modal').click(function(event) {
				$(this).modal('hide');
			});
		});		
	</script>
  </body>
</html>