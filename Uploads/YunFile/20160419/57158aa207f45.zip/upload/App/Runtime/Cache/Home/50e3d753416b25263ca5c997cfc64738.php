<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>
	<head>
		<style>
		 #box{
		 width:150px;height:150px;border:1px dashed red;
		 font-size:13px;line-height:150px;text-align:center;
		 }
		</style>
		<script>
		 window.onload=function  () {
		  var box=document.getElementById("box");
		  box.ondragenter=function  (e) {
		  e.preventDefault()
		  }
		  box.ondragover=function  (e) {
		  box.innerHTML="���ɿ�"
		   e.preventDefault()
		  }
		  box.ondragleave=function  (e) {
		   box.innerHTML="�������ϴ����ļ�"
		  e.preventDefault()
		  }
		  box.ondrop=function  (e) {
		  var file=e.dataTransfer.files[0];
		  var formData=new FormData(); 
           formData.append("aa",file);
		  var xml=new XMLHttpRequest();
		  xml.open("post","up.php");
		  xml.send(formData);
           e.preventDefault()
		  }
		 }
		</script>
	</head>
	<body>
	   <div id="box">
	     �������ϴ����ļ�
	   </div>
	</body>
</html>