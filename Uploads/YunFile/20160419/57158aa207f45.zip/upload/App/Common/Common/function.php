<?php 
	//获取缩略图地址
	function get_tb_img_url($img_url){		
        $info=pathinfo($img_url);
        $path=$info['dirname'];
        $name=$info['basename'];
        // $ext=$info['extension'];
        $tb_img_url=$path.'/tb_'.$name;

        return $tb_img_url;
	}